# Notebook
The main file is https://github.com/AkinoriTanaka-phys/DL_holographicQCD/blob/master/QCD_public.ipynb.

# Requirements
Language is `python`. We need following libraries:
* `csv`
* `matplotlib`
* `numpy`
* `math`

If your python embiroment was built by **`anaconda`**, they are already installed.
In addition, we need deep learning library 
* `torch`
* `torchvision`

Please access https://pytorch.org how to download them.
